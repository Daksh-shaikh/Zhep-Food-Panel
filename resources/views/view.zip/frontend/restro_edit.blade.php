@extends('frontend.layout.header')

@section('main-container')
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-12 mx-auto">


						<div class="card">
							<div class="card-body">

                                @if ($errors->any())
                                <div class="alert alert-danger mt-2">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif


								<h6>Edit Restaurant</h6>
								<hr>
								<form class="row g-2" action="{{route('restroUpdate')}}" method="post" enctype="multipart/form-data">
                                    @csrf
									<div class="col-lg-2">
                                        @if ($errors->any())
                                        <div class="alert alert-danger">
                                            <ul>
                                                @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                        @endif

                                        <input type="hidden" name="id" value="{{$restroEdit->id}}"/>

                                        <label class="form-label">Select City</label>
											<select class="single-select" name="city">
												{{-- <option value="Amravati" {{ $restroEdit->city == 'Amravati' ? 'selected' : '' }}>Amravati</option>
												<option value="Akola" {{ $restroEdit->city == 'Akola' ? 'selected' : '' }}>Akola</option>
												<option value="Nagpur" {{ $restroEdit->city == 'Nagpur' ? 'selected' : '' }}>Nagpur</option> --}}
                                                @foreach ($city as $city_name)
                                                <option value="{{$city_name->id}}">{{$city_name->city}}</option>
                                                @endforeach

											</select>
									</div>
									<div class="col-lg-2">
										<label class="form-label">Restaurant Name</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="restaurant" value="{{$restroEdit->restaurant}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Latitude</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="latitude" value="{{$restroEdit->latitude}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Longitude</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="longitude" value="{{$restroEdit->longitude}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Contact Person</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="contact_person" value="{{$restroEdit->contact_person}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Mobile No</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="mobilenumber" value="{{$restroEdit->mobilenumber}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Email / Username</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="email" value="{{$restroEdit->email}}">

									</div>
                                    <div class="col-lg-2">
										<label class="form-label">Password</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="password" value="{{$restroEdit->password}}">

									</div>

                                    <div class="col-lg-2">
										<label class="form-label">Avg Cooking Time</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="avg_cooking_time" value="{{$restroEdit->avg_cooking_time}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Upload Banner</label>
										<input type="file" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="banner" value="{{$restroEdit->banner}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Select Category</label>
										<select class="multiple-select" multiple="multiple" name="category">
											{{-- <option value="Amravati" {{ $restroEdit->category == 'Amravati' ? 'selected' : '' }}>Amravati</option>
											<option value="Akola" {{ $restroEdit->category == 'Akola' ? 'selected' : '' }}>Akola</option>
											<option value="Nagpur" {{ $restroEdit->category == 'Nagpur' ? 'selected' : '' }}>Nagpur</option> --}}
                                            @foreach ($category as $category_name)
                                            <option value="{{$category_name->id}}">{{$category_name->category}}</option>

                                            @endforeach
										</select>
								</div>
								<div class="col-lg-1" style="margin-top: 35px;">
										<input class="form-check-input" type="checkbox" value="Veg" name="food[]" id="flexCheckDefault" >
										<label class="form-check-label" for="flexCheckDefault">Veg</label>

								</div>

								<div class="col-lg-1" style="margin-top: 35px;">
									<input class="form-check-input" type="checkbox" value="Non-Veg" name="food[]" id="flexCheckDefault1">
									<label class="form-check-label" for="flexCheckDefault1">Non-Veg</label>

							</div>

							<div class="col-lg-3">
								<label for="inputAddress2" class="form-label">Restaurant Details</label>
								<textarea class="form-control" id="inputAddress2" placeholder="" rows="3" name="details">{{$restroEdit->details}}</textarea>
							</div>
									<div class=""  align="center">
										{{-- <button type="submit" class="btn btn-success"><i
											class="lni lni-circle-plus"></i>Update</button> --}}
                                            <button style="background-color:#17a00e; color:white; border:none; max-height:35px; margin-top: 3px; "
                                            type="submit" class="btn btn-success" data-toggle="tooltip" data-placement="top" data-original-title="" title=""><i class="fa fa-edit" style="color: white"></i>Update</button>

									</div>
								</form>

							</div>

						</div>
					</div>
				</div>



				<!--end page wrapper -->
				<!--start overlay-->
				<div class="overlay toggle-icon"></div>
				<hr />
				<div class="col-md-12 mx-auto">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example" class="table table-striped table-bordered">
									<thead>
										<tr>
											<th>Sr No</th>
											<th>City</th>
											<th>Restaurant Name</th>
											<th>Latitude</th>
											<th>Longitude</th>
											<th>Contact Person</th>
											<th>Mobile</th>
											<th>Email</th>
											<th>Banner</th>
											<th>Category</th>
											<th>Veg/Non-Veg</th>
											{{-- <th>GST</th> --}}
											<th>Restaurant Details</th>
											<th style="background-color: #ffffff;">Action</th>
										</tr>
									</thead>
									<tbody>

										@foreach ($restroCollection as $item)


										<tr>
											<td>{{$loop->index+1}}</td>
                                            <td>
                                                @if($item->city_name)
                                                    {{ $item->city_name->city }}
                                                @else
                                                    null
                                                @endif
                                            </td>
											<td>{{$item->restaurant}}</td>
											<td>{{$item->latitude}}</td>
											<td>{{$item->longitude}}</td>
											<td>{{$item->contact_person}}</td>
											<td>{{$item->mobilenumber}}</td>
											<td>{{$item->email}}</td>
											<td>{{$item->banner}}</td>
                                            <td>
                                                @if($item->category_name)
                                                    {{ $item->category_name->category }}
                                                @else
                                                    null
                                                @endif
                                            </td>
                                            <td>
                                                @if($item->food)
                                                    @php
                                                        $decodedFood = json_decode($item->food, true);
                                                    @endphp

                                                    @if(is_array($decodedFood))
                                                        {{ implode(', ', $decodedFood) }}
                                                    @else
                                                        {{ $item->food }}
                                                    @endif
                                                @endif
                                            </td>

											<td>{{$item->details}}</td>
											{{-- <td>{{$item->city}}</td> --}}
											<td style="background-color: #ffffff;">

                                                        <a href="{{route('restroDestroy', $item->id)}}">
                                                            <button
                                                        type="button" class="btn1 btn-outline-danger" title="button"><i
                                                            class='bx bx-trash me-0'></i>
                                                            </a>
											</td>
										</tr>
                                        @endforeach
									</tbody>

								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>



		<!--end page wrapper -->
		@endsection
