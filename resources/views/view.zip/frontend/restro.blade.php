@extends('frontend.layout.header')

@section('main-container')
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-12 mx-auto">


						<div class="card">
							<div class="card-body">

                                @if ($errors->any())
                                <div class="alert alert-danger mt-2">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif


								<h6>Add Restaurant</h6>
								<hr>
								<form class="row g-2" action="{{route('restroStore')}}" method="post" enctype="multipart/form-data">
                                    @csrf
									<div class="col-lg-2">

                                        <label class="form-label">Select City</label>
											<select class="single-select" name="city">
												{{-- <option value="Amravati">Amravati</option>
												<option value="Akola">Akola</option>
												<option value="Nagpur">Nagpur</option> --}}

                                                <option value="">--Select--</option>
                                                @foreach ($city as $city_name)
                                                <option value="{{$city_name->id}}">{{$city_name->city}}</option>

                                                @endforeach

											</select>
									</div>
									<div class="col-lg-2">
										<label class="form-label">Restaurant Name</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="restaurant">

									</div>

                                    <div class="col-lg-2">
										<label class="form-label">Address</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="address">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Latitude</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="latitude">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Longitude</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="longitude">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Contact Person</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="contact_person">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Mobile No</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="mobilenumber">

									</div>

									<div class="col-lg-2">
                                        <label class="form-label">Email / Username </label>
                                        <input type="text" class="form-control" name="email" value="">
                                    </div>

                                    <div class="col-lg-2">
                                        <label class="form-label">Password</label>
                                        <input type="password" class="form-control" name="password" value="">
                                    </div>

                                    <div class="col-lg-2">
										<label class="form-label">Avg Cooking Time</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="avg_cooking_time">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Upload Banner</label>
										<input type="file" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="banner">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Select Category</label>
										<select class="multiple-select" multiple="multiple" name="category">
											{{-- <option value="Amravati">Amravati</option>
											<option value="Akola">Akola</option>
											<option value="Nagpur">Nagpur</option> --}}
                                            @foreach ($category as $category_name)
                                            <option value="{{$category_name->id}}">{{$category_name->category}}</option>

                                            @endforeach

										</select>
								</div>
								<div class="col-lg-1" style="margin-top: 35px;">
										<input class="form-check-input" type="checkbox" value="Veg" name="food[]" id="flexCheckDefault" >
										<label class="form-check-label" for="flexCheckDefault">Veg</label>

								</div>

								<div class="col-lg-1" style="margin-top: 35px;">
									<input class="form-check-input" type="checkbox" value="Non-Veg" name="food[]" id="flexCheckDefault1">
									<label class="form-check-label" for="flexCheckDefault1">Non-Veg</label>

							</div>

							<div class="col-lg-3">
								<label for="inputAddress2" class="form-label">Restaurant Details</label>
								<textarea class="form-control" id="inputAddress2" placeholder="" rows="3" name="details"></textarea>
							</div>
									<div class=""  align="center">
										<button type="submit" class="btn btn-success"><i
											class="lni lni-circle-plus"></i>Add</button>
									</div>
								</form>

							</div>

						</div>
					</div>
				</div>



				<!--end page wrapper -->
				<!--start overlay-->
				<div class="overlay toggle-icon"></div>
				<hr />
				<div class="col-md-12 mx-auto">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example" class="table table-striped table-bordered">
									<thead>
										<tr>
											<th>Sr No</th>
                                            <th>City</th>
											<th>Restaurant Name</th>
                                            <th>Address</th>
											<th>Contact Person</th>
											<th>Mobile</th>
											<th>Email / Username</th>
                                            {{-- <th>Password</th> --}}
                                            <th>Average Cooking Time</th>
											<th>Banner</th>
											<th>Category</th>
											<th>Veg/Non-Veg</th>
                                            <th>Latitude</th>
											<th>Longitude</th>
											{{-- <th>GST</th> --}}
											<th>Restaurant Details</th>

											<th style="background-color: #ffffff;">Action</th>
										</tr>
									</thead>
									<tbody>

										@foreach ($restro as $restro)


										<tr>
											<td>{{$loop->index+1}}</td>
											{{-- <td>{{$restro->city_name->city}}</td> --}}
                                            <td>
                                                @if($restro->city_name)
                                                    {{ $restro->city_name->city }}
                                                @else
                                                    null
                                                @endif
                                            </td>
											<td>{{$restro->restaurant}}</td>
                                            <td>{{$restro->address}}</td>
											<td>{{$restro->contact_person}}</td>
											<td>{{$restro->mobilenumber}}</td>
											<td>{{$restro->email}}</td>
                                            {{-- <td>{{$restro->password}}</td> --}}
                                            <td>{{$restro->avg_cooking_time}}</td>
											<td>
                                                <a href="{{asset('banner/'. $restro->banner)}}"></a>
                                                <img height="50px" width="50px"  src="{{asset('banner/'. $restro->banner)}}" alt="" />

                                                {{-- {{$restro->banner}} --}}
                                            </td>
											{{-- <td>{{$restro->category}}</td> --}}
                                            <td>
                                                @if($restro->category_name)
                                                    {{ $restro->category_name->category}}
                                                @else
                                                    null
                                                @endif
                                            </td>
											{{-- <td>{{$restro->food}}</td> --}}



                                                <td>
                                                    @if($restro->food)
                                                        @php
                                                            $decodedFood = json_decode($restro->food, true);
                                                        @endphp

                                                        @if(is_array($decodedFood))
                                                            {{ implode(', ', $decodedFood) }}
                                                        @else
                                                            {{ $restro->food }}
                                                        @endif
                                                    @endif
                                                </td>

                                            </td>

                                            <td>{{$restro->latitude}}</td>
											<td>{{$restro->longitude}}</td>
											<td>{{$restro->details}}</td>



											<td style="background-color: #ffffff;">

                                                <a href="{{ route('adminDashboard', ['email' => $email, 'password' => $password]) }}">Login</a>
                                                <a href="{{route('restroEdit', $restro->id)}}">
                                                    <button type="button" class="btn1 btn-outline-success"><i
														class='bx bx-edit-alt me-0'></i></button>
                                                    </a>
                                                        {{-- <button type="button"
													class="btn1 btn-outline-danger"><i
														class='bx bx-trash me-0'></i></button> --}}

                                                        <a href="{{route('restroDestroy', $restro->id)}}">
                                                            <button
                                                        type="button" class="btn1 btn-outline-danger" title="button"><i
                                                            class='bx bx-trash me-0'></i></button>
                                                            </a>
											</td>
										</tr>
                                        @endforeach
									</tbody>

								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>



		<!--end page wrapper -->
		@endsection
