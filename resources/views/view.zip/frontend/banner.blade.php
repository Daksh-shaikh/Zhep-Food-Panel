@extends('frontend.layout.header')

@section('main-container')

		<!--end header -->
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-8 mx-auto">


						<div class="card">
							<div class="card-body">
                                @if ($errors->any())
                                <div class="alert alert-danger mt-2">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif


								<h6>Add Banner </h6>
								<hr>
								<form class="row g-2" method='post' action="{{route('bannerStore')}}" enctype="multipart/form-data">
                                    @csrf
									<div class="col-md-3"></div>
									<div class="col-lg-5">
										<label class="form-label">Upload Banner <span style="color: red; font-size:12px;">(Size 900px*400px)</span></label>
										<input type="file" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="banner">

									</div>
									<div class="col-md-2" style="margin-top:35px;">
										<button type="submit" class="btn btn-success"><i
											class="lni lni-circle-plus"></i>Add</button>
									</div>
								</form>

							</div>

						</div>
					</div>
				</div>



				<!--end page wrapper -->
				<!--start overlay-->
				<div class="overlay toggle-icon"></div>
				<hr />
				<div class="col-md-8 mx-auto">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example" class="table table-striped table-bordered">
									<thead>
										<tr>
											<th>Sr No</th>
											<th>Banner</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>

                                        @foreach ($banner as $banner)


										<tr>
											<td>{{$loop->index+1}}</td>
											<td>
                                                <a href="{{asset('banner/'. $banner->banner)}}"></a>
                                                <img height="50px" width="50px"  src="{{asset('banner/'. $banner->banner)}}" alt="" />
                                            </td>
											<td>
                                                <a href="{{route('bannerEdit', $banner->id)}}">
                                                <button type="button" class="btn1 btn-outline-success"><i
														class='bx bx-edit-alt me-0'></i></button>
                                                    </a>

                                                        <a href="{{route('bannerDestroy', $banner->id)}}">
                                                        <button type="button"
													class="btn1 btn-outline-danger"><i
														class='bx bx-trash me-0'></i></button>
                                                    </a>
                                                    </td>
										</tr>

                                        @endforeach
									</tbody>

								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>



@endsection
