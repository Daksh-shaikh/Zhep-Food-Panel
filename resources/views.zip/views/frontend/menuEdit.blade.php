@extends('frontend.layout.header')

@section('main-container')
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-12 mx-auto">


						<div class="card">
							<div class="card-body">

                                @if ($errors->any())
                                <div class="alert alert-danger mt-2">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif

                            @if(session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif


								<h6>Add Menu</h6>
								<hr>
								<form class="row g-2" action="{{route('menuUpdate')}}" method="post" enctype="multipart/form-data">
                                    @csrf
									<div class="col-lg-2">
                                        <input type="hidden" name="id" value="{{$menuEdit->id}}"/>

                                        <label class="form-label">Select Restaurant</label>
											<select class="single-select" name="restaurant">
                                                <option value="">--Select--</option>
                                                @foreach ($restro as $restro_name)
                                                <option value="{{$restro_name->id}}"
                                                    {{-- >{{$restro_name->restaurant}}</option> --}}
                                                {{ old('restaurant', $menuEdit->restaurant_id) == $restro_name->id ? 'selected' : '' }}>
                                                {{ $restro_name->restaurant}}</option>
                                                @endforeach

                                                {{-- <option value="">--Select--</option>
                                                @foreach ($city as $city_name)
                                                <option value="{{$city_name->id}}">{{$city_name->city}}</option>

                                                @endforeach --}}

											</select>
									</div>
									<div class="col-lg-2">
                                        <label class="form-label">Select Category</label>
                                        <select class="single-select" name="category">
                                            <option value="">--Select--</option>
                                            @foreach ($category as $category_name)
                                            <option value="{{$category_name->id}}"
                                                {{ old('category', $menuEdit->category_id) == $category_name->id ? 'selected' : '' }}>
                                                {{ $category_name->category}}</option>
                                                {{-- >{{$category_name->category}}</option> --}}

                                            @endforeach

                                            {{-- <option value="">--Select--</option>
                                            @foreach ($city as $city_name)
                                            <option value="{{$city_name->id}}">{{$city_name->city}}</option>

                                            @endforeach --}}

                                        </select>
									</div>

									<div class="col-lg-2">
										<label class="form-label">Recipe Name</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="recipe" value="{{$menuEdit->recipe}}">

									</div>

									<div class="col-lg-2">
										<label class="form-label">Price</label>
										<input type="text" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="price" value="{{$menuEdit->price}}">

									</div>

                                    {{-- <div class="col-lg-1" style="margin-top: 35px;">
                                        <input class="form-check-input" type="checkbox" value="Veg" name="food[]" id="flexCheckDefault" @if(in_array('Veg', json_decode($menuEdit->food))) checked @endif>
                                        <label class="form-check-label" for="flexCheckDefault">Veg</label>
                                    </div>

                                    <div class="col-lg-1" style="margin-top: 35px;">
                                        <input class="form-check-input" type="checkbox" value="Non-Veg" name="food[]" id="flexCheckDefault1" @if(in_array('Non-Veg', json_decode($menuEdit->food))) checked @endif>
                                        <label class="form-check-label" for="flexCheckDefault1">Non-Veg</label>
                                    </div> --}}

                                    {{-- to show preselected checkboxes --}}
                                    {{-- <?php
                                    // $decodedFood = json_decode($menuEdit->food, true);

                                    // // If it's not an array, convert it to an array
                                    // if (!is_array($decodedFood)) {
                                    //     $decodedFood = [$menuEdit->food];
                                    // }
                                    ?>
                                    <pre>{{ var_dump($menuEdit->food, $decodedFood) }}</pre>



                                    <div class="col-lg-1" style="margin-top: 35px;">
                                        <input class="form-check-input" type="checkbox" value="Veg" name="food[]" id="flexCheckDefault"
                                            @if(in_array('Veg', explode(',', $menuEdit->food))) checked @endif>
                                        <label class="form-check-label" for="flexCheckDefault">Veg</label>
                                    </div>

                                    <div class="col-lg-1" style="margin-top: 35px;">
                                        <input class="form-check-input" type="checkbox" value="Non-Veg" name="food[]" id="flexCheckDefault1"
                                            @if(in_array('Non-Veg', explode(',', $menuEdit->food))) checked @endif>
                                        <label class="form-check-label" for="flexCheckDefault1">Non-Veg</label>
                                    </div>



 --}}

                        <?php
                        $decodedFood = json_decode($menuEdit->food, true);

                        // If it's not an array, convert it to an array
                        if (!is_array($decodedFood)) {
                            $decodedFood = [$menuEdit->food];
                        }
                        ?>

                        {{-- <pre>{{ var_dump($menuEdit->food, $decodedFood) }}</pre> --}}

                        <div class="col-lg-1" style="margin-top: 35px;">
                            <input class="form-check-input" type="checkbox" value="Veg" name="food[]" id="flexCheckDefault"
                                @if(is_array($decodedFood) && in_array('Veg', $decodedFood)) checked @endif>
                            <label class="form-check-label" for="flexCheckDefault">Veg</label>
                        </div>

                        <div class="col-lg-1" style="margin-top: 35px;">
                            <input class="form-check-input" type="checkbox" value="Non-Veg" name="food[]" id="flexCheckDefault1"
                                @if(is_array($decodedFood) && in_array('Non-Veg', $decodedFood)) checked @endif>
                            <label class="form-check-label" for="flexCheckDefault1">Non-Veg</label>
                        </div>



                                    <div class="col-lg-2">
										<label class="form-label">Recipe image</label>
										<input type="file" class="form-control" id="exampleInputEmail1"
											aria-describedby="emailHelp" placeholder="" name="image" value="{{$menuEdit->image}}">
                                            {{-- <img src="{{ asset('recipe/' . $menuEdit->image) }}" alt="Current Image" width="50" height="50"> --}}

									</div>

									<div class="col-lg-3">
										<label for="inputAddress2" class="form-label">Recipe Description</label>
										<textarea class="form-control" id="inputAddress2" placeholder=""
                                        rows="3" name="description" >{{$menuEdit->description}}</textarea>
									</div>

										<div class=""  align="center">
										<button type="submit" class="btn btn-success"><i
											class="fa fa-edit"></i>Update</button>
									</div>
								</form>

							</div>

						</div>
					</div>
				</div>



				<!--end page wrapper -->
				<!--start overlay-->
				<div class="overlay toggle-icon"></div>
				<hr />
				<div class="col-md-12 mx-auto">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example" class="table table-striped table-bordered">
									<thead>
										<tr>
											<th>Sr No</th>
											<th>Restaurant Name</th>
											<th>Category</th>
											<th>Recipe Name</th>
											<th>Price</th>
											<th>Recipe Image</th>
											<th>Recipe Description</th>
											<th style="background-color: #ffffff;">Action</th>
										</tr>
									</thead>
									<tbody>
                                        @foreach ($menuAll as $menuAll)

										<tr>
											<td>{{$loop->index+1}}</td>

                                            <td>
                                                {{-- {{$menu->restaurant_name->restaurant}} --}}
                                                @if($menuAll->restaurant_name)
                                                {{ $menuAll->restaurant_name->restaurant}}
                                            @else
                                                null
                                            @endif</td>


                                            {{-- <td>{{$menuAll->restaurant_id}}</td> --}}
											{{-- <td>{{$menuAll->category_id}}</td> --}}

                                            <td>
                                                {{-- {{$menu->category_id}} --}}
                                                @if($menuAll->category_name)
                                                {{ $menuAll->category_name->category}}
                                            @else
                                                null
                                            @endif

                                            </td>
											<td>{{$menuAll->recipe}}</td>

                                            <td>
                                                @if($menuAll->food)
                                                    @php
                                                        $decodedFood = json_decode($menuAll->food, true);
                                                    @endphp

                                                    @if(is_array($decodedFood))
                                                        {{ implode(', ', $decodedFood) }}
                                                    @else
                                                        {{ $menuAll->food }}
                                                    @endif
                                                @endif
                                            </td>
											<td>{{$menuAll->price}}</td>
                                            <td>
                                                <a href="{{asset('recipe/'. $menuAll->image)}}"></a>
                                                <img height="50px" width="50px"  src="{{asset('recipe/'. $menuAll->image)}}" alt="" />

                                                {{-- {{$restro->banner}} --}}
                                            </td>
                                            <td>{{$menuAll->description}}</td>


											<td style="background-color: #ffffff;">


                                                        <a href="{{route('menuDestroy', $menuAll->id)}}">
                                                            <button
                                                        type="button" class="btn1 btn-outline-danger" title="button"
                                                        onclick="confirmDelete({{ $menuAll->id }})"><i
                                                            class='bx bx-trash me-0'></i></button>
                                                            </a>
											</td>
										</tr>
                                        @endforeach

									</tbody>

								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>



		<!--end page wrapper -->
		@endsection


    {{-- to show confirmation alert message while delete --}}
    <script>
        function confirmDelete(menuId) {
            var result = confirm('Are you sure you want to delete this Menu?');
            if (!result) {
                event.preventDefault(); // Prevent the default action (deletion) if user clicks "Cancel"
            } else {
                window.location.href = '{{ url("menuDestroy") }}/' + menuId;
            }
        }
    </script>
